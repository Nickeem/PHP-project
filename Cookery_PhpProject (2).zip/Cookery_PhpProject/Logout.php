<!-- Creator: Nickeem -->
<?php
 session_start();
 session_destroy();
 header('Location: indexLogin.php');
 exit;

 ?>
